my_typ={"name":"Alice","age":"30","profession":"Teacher"};
