#include <stdio.h>

struct type
{
	int age;
	char *name;
	char *profession;
};

int main()
{

	return 0;
}
